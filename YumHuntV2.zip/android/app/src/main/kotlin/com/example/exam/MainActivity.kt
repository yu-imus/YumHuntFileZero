package com.example.exam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
