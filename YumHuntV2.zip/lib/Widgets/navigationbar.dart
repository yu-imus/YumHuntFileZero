import 'package:flutter/material.dart';
import '../Screens/home.dart';
import '../Screens/cart.dart';

class MyBottomNavigationBar extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onItemTapped;

  MyBottomNavigationBar({
    required this.selectedIndex,
    required this.onItemTapped,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60, // Adjust the height as needed
      child: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Color(0xFFEFE4E1),
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.black,
        selectedFontSize: 14,
        unselectedFontSize: 14,
        currentIndex: selectedIndex,
        onTap: (index) {
          // Execute the provided callback function
          onItemTapped(index);

          // Navigate to the corresponding page
          switch (index) {
            case 0:
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => HomeScreen()),
              );
              break;
            case 1:
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => HomeScreen()),
              );
              break;
            case 2:
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => CartScreen()),
              );
              break;
          }
        },
        items: [
          BottomNavigationBarItem(
            label: '',
            icon: Center(
              child: ImageIcon(
                AssetImage('assets/images/octicon_search-16.png'),
              ),
            ),
          ),
          BottomNavigationBarItem(
            label: '',
            icon: Center(
              child: ImageIcon(
                AssetImage('assets/images/octicon_home-16.png'),
              ),
            ),
          ),
          BottomNavigationBarItem(
            label: '',
            icon: Center(
              child: ImageIcon(
                AssetImage(
                    'assets/images/fluent-emoji-high-contrast_fork-and-knife-with-plate.png'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
