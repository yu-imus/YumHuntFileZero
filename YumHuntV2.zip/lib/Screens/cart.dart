/* Authored by: Vincent Dolera
Company: MVY
Project: YumHunt
Feature: [MVY-000] Landing Page
Description: This is the first page you will see when you open the app,
where you have to choose if you are a student, staff, or a vendor
 */

import 'package:flutter/material.dart';
import '../Widgets/navigationbar.dart'; // Import the new file

void main() {
  runApp(CartScreen());
}

class CartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginDemo(),
    );
  }
}

class LoginDemo extends StatefulWidget {
  @override
  _LoginDemoState createState() => _LoginDemoState();
}

class _LoginDemoState extends State<LoginDemo> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "assets/images/Picture.png"), // Replace with your image path
            fit: BoxFit.fill,
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 0),
                child: Center(
                  child: Column(
                    children: [
                      AppBar(
                        leading: Icon(Icons.menu),
                        title: Align(
                          alignment: Alignment.center,
                          child: Text('Your Plate',
                              style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                        backgroundColor: Colors.white,
                      ),
                      SizedBox(height: 20),
                      Text('Review your orders before confirming!',
                          style: TextStyle(fontSize: 15)),
                      SizedBox(height: 40),
                      buildContainer(
                          'Kapehan Nindo',
                          '1x Classic Kape 12oz[Iced]',
                          'P60.00',
                          Color(0xFFFFD8A9),
                          Color(0xFF91CB9D)),
                      SizedBox(height: 40),
                      buildContainer(
                          'NOMO',
                          '2x Inli Chicken\n3x Unli Pork Chili',
                          'P495.00',
                          Color(0xFFFFD8A9),
                          Color(0xFF91CB9D)),
                      SizedBox(height: 40),
                      buildContainer('KOPI Club', '2x Iced Matcha', 'P198.00',
                          Color(0xFFFFD8A9), Color(0xFF91CB9D)),
                      SizedBox(height: 150),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: MyBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemTapped: _onItemTapped,
      ),
    );
  }

  Widget buildContainer(String title, String items, String total,
      Color editButtonColor, Color confirmButtonColor) {
    return Column(
      children: [
        Container(
          width: 250,
          padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 10,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Divider(height: 20, thickness: 2),
              Text(items),
              Divider(height: 20, thickness: 2),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Total:', style: TextStyle(fontWeight: FontWeight.bold)),
                  Text(total, style: TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            ],
          ),
        ),
        SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            TextButton(
              onPressed: () {
                // Action when "Edit" button is pressed
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(editButtonColor),
              ),
              child: Text(
                'Edit',
                style:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
              ),
            ),
            TextButton(
              onPressed: () {
                // Action when "Confirm" button is pressed
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(confirmButtonColor),
              ),
              child: Text('Confirm',
                  style: TextStyle(
                      color: Colors.black, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ],
    );
  }
}
