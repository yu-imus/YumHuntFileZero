import 'package:flutter/material.dart';
import '../Widgets/appbar.dart';
import '../Widgets/categories.dart';
import '../Widgets/shoplist.dart';
import '../Widgets/navigationbar.dart'; // Import the navigation bar widget

void main() {
  runApp(HomeStart());
}

class HomeStart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Food App",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: Color(0xFFFFD8A9),
      ),
      routes: {
        "/": (context) => HomeScreen(),
      },
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomeScreen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFFD8A9), // Set the background color here
      body: ListView(
        children: [
          YumAppBar(),
          Padding(
            padding: EdgeInsets.only(top: 20, left: 10),
            child: Text(
              "Categories",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            ),
          ),
          FoodCategory(),
          Padding(
            padding: EdgeInsets.only(top: 20, left: 10),
            child: Text(
              "Stores",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            ),
          ),
          ShopWidget(),
        ],
      ),
      bottomNavigationBar: MyBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemTapped: _onItemTapped,
      ),
    );
  }
}
