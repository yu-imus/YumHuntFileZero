import 'package:flutter/material.dart';

class ShopWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        child: Column(
          children: [
            _buildShopContainer(
              image: "assets/images/NOMO.png",
              name: "NOMO",
            ),
            _buildShopContainer(
              image: "assets/images/kopiclub.png",
              name: "Kopiclub",
            ),
            _buildShopContainer(
              image: "assets/images/kapehannindo.png",
              name: "Kapehannindo",
            ),
            _buildShopContainer(
              image: "assets/images/whitehousekitchen.png",
              name: "Whitehouse Kitchen",
            ),
            _buildShopContainer(
              image: "assets/images/NoodleHouse.png",
              name: "Noodle House",
            ),
            _buildShopContainer(
              image: "assets/images/cloudchicken.png",
              name: "Cloud Chicken",
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildShopContainer({required String image, required String name}) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 10),
      child: Container(
        width: 380,
        height: 150,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 3,
              blurRadius: 10,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Stack(
          children: [
            Image.asset(
              image,
              fit: BoxFit.fill,
              height: 150,
              width: 380,
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(10),
                    bottomRight: Radius.circular(10),
                  ),
                ),
                child: Center(
                  child: Text(
                    name,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
